package soot.jimple.infoflow.android.Analysis;




import javafx.util.Pair;
import soot.*;
import soot.jimple.*;
import soot.jimple.infoflow.android.axml.AXmlComplexValue;
import soot.jimple.infoflow.android.haniyehUtil;
import soot.jimple.internal.AbstractInvokeExpr;
import soot.toolkits.graph.ClassicCompleteUnitGraph;
import soot.toolkits.graph.DirectedGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.ForwardFlowAnalysis;

import java.util.ArrayList;
import java.util.List;

public class ResourceLeakAnalysis extends ForwardFlowAnalysis<Unit, LeakFlowSet> {


    public SootMethod parentMethod;
    public ResourceLeakAnalysis(DirectedGraph graph, SootMethod parentMethod) {
        super(graph);
        //System.out.println("222222");

        this.parentMethod = parentMethod;
        //this.analysisMode = analysisMode;
        //doAnalysis();
    }

    public void start(){
        doAnalysis();
    }

    @Override
    protected void flowThrough(LeakFlowSet inSet, Unit unit, LeakFlowSet outSet) {
        //System.out.println("33333");

        inSet.copy(outSet);
        kill(inSet, unit, outSet);
        generate(inSet, unit, outSet);
    }


    @Override
    protected LeakFlowSet newInitialFlow() {
        return new LeakFlowSet();
    }





    @Override
    protected void merge(LeakFlowSet inSet1, LeakFlowSet inSet2, LeakFlowSet outSet) {
        //if(analysisMode != AnalysisMode.MUST)
        inSet1.union(inSet2, outSet);
        //else
            //inSet1.intersection(inSet2, outSet);
    }

    @Override
    protected void copy(LeakFlowSet source, LeakFlowSet dest) {
        source.copy(dest);
    }

    public boolean findSameRef(List<Value> args1, List<Value> args2){
        Value wantedArg1 = null;
        Value wantedArg2 = null;
        boolean found = false;
        for(Value arg1: args1){

            for(Value arg2 :args2){

                //FieldRef f = (FieldRef) arg1;

                if(arg1.equivHashCode() == arg2.equivHashCode()){
                    if( (Scene.v().getSootClassUnsafe(arg1.getType().toString()) != null) &&
                            (Scene.v().getSootClassUnsafe(arg2.getType().toString()) != null) ){
                        SootClass arg1Class = Scene.v().getSootClass(arg1.getType().toString());
                        SootClass arg2Class = Scene.v().getSootClass(arg2.getType().toString());
                        if(arg1Class.implementsInterface("android.hardware.SensorEventListener") &&
                                arg2Class.implementsInterface("android.hardware.SensorEventListener")){
                            wantedArg1 = arg1;
                            wantedArg2 = arg2;
                            found = true;
                            break;
                        }
                        /*if((arg1Class.hasSuperclass() && arg1Class.getSuperclass().getName().equals("android.location.LocationListener")) &&
                                (arg2Class.hasSuperclass() && arg2Class.getSuperclass().getName().equals("android.location.LocationListener"))){
                            wantedArg1 = arg1;
                            wantedArg2 = arg2;
                            found = true;
                            break;
                        }
                        if((arg1Class.getName().equals("android.location.LocationListener")) &&
                                (arg2Class.getName().equals("android.location.LocationListener"))){
                            wantedArg1 = arg1;
                            wantedArg2 = arg2;
                            found = true;
                            break;
                        }*/
                    }

                }
            }

            if (found)
                break;


        }
        return found;
        //return arg1.equivTo(arg2);
    }

    public boolean checkAndRemove(LeakFlowSet outSet, List<Value> args, String removeMethod, String addMethod){
        //boolean foundRequest = false;
        //boolean foundRelease = false;
        //List<Value> args = ((AbstractInvokeExpr) useBox.getValue()).getArgs();
        for(Result res: outSet) {
            if(res.getFinalMethod().getName().contains(removeMethod)){
                if(findSameRef(res.getArgs(),args)){
                    outSet.remove(res);
                    //foundRequest = true;
                }
            }

            /*if(res.getFinalMethod().getName().contains(addMethod)){
                if(findSameRef(res.getArgs(),args)){
                    //outSet.remove(res);
                    foundRelease = true;
                }
            }*/
        }

        return true;

    }

    public void checkMethodStatus(Unit unit, LeakFlowSet outSet, SootMethod sootMethod, String addMethod, String removeMethod){

        if(haniyehUtil.getInstance().notVisitedMethodToAnalysis.containsKey(sootMethod.getSignature())) {
            ResourceLeakAnalysis ra = haniyehUtil.getInstance().notVisitedMethodToAnalysis.get(sootMethod.getSignature());
            haniyehUtil.getInstance().notVisitedMethodToAnalysis.remove(sootMethod.getSignature());
            haniyehUtil.getInstance().beingVisitedMethods.add(sootMethod.getSignature());
            ra.start();

            Unit lastUnit = sootMethod.getActiveBody().getUnits().getLast();
            List<Result> methodResults = new ArrayList<>();

            for(Result rs: ra.getFlowAfter(lastUnit)){
                //rs.setCallBackClass(sm.getDeclaringClass());
                //rs.setCallBackMethod(sm);
                if(rs.getFinalMethod().getName().contains(addMethod)){
                    if(checkAndRemove(outSet, rs.getArgs(), removeMethod, addMethod)){
                        rs.getPathMethods().add(new Pair<>(((Unit) unit) , parentMethod));
                        outSet.add(rs);
                    }
                }
                methodResults.add(rs);
            }
            haniyehUtil.getInstance().results.put(sootMethod.getSignature(), methodResults);

        }

        else if(haniyehUtil.getInstance().results.containsKey(sootMethod.getSignature())){
            for(Result rs: haniyehUtil.getInstance().results.get(sootMethod.getSignature())){
                //rs.setCallBackClass(sm.getDeclaringClass());
                //rs.setCallBackMethod(sm);
                if(rs.getFinalMethod().getName().contains(addMethod)){
                    if(checkAndRemove(outSet, rs.getArgs(), removeMethod, addMethod)){
                        rs.getPathMethods().add(new Pair<>(((Unit) unit) , parentMethod));
                        outSet.add(rs);
                    }
                }
                //methodResults.add(rs);
            }
        }
    }

    protected void kill(LeakFlowSet inSet, Unit unit, LeakFlowSet outSet){
        /*unit.apply(new AbstractStmtSwitch() {
            @Override
            public void caseAssignStmt(AssignStmt stmt) {
                Local leftOp = (Local) stmt.getLeftOp();
                outSet.remove(leftOp);
            }
        });*/

        //System.out.println("444444");

        for (ValueBox useBox : unit.getUseBoxes()) {
            if(useBox.getValue() instanceof AbstractInvokeExpr) {
                //System.out.println("double shit");
                //System.out.println("555555");
                //if(((AbstractInvokeExpr) useBox.getValue()).getMethod().getSubSignature()
                //        .equals("void removeUpdates(android.location.LocationListener)")){
                if(((AbstractInvokeExpr) useBox.getValue()).getMethod().getName().contains("removeUpdates")){
                    //System.out.println("6666666");
                    if(checkAndRemove(outSet,((AbstractInvokeExpr) useBox.getValue()).getArgs(),"requestLocationUpdates", "removeUpdates")){
                        Result newResult = produceNewResult(unit, useBox.getValue());
                        outSet.add(newResult);
                    }
                }
                else {
                    if( (((AbstractInvokeExpr) useBox.getValue()).getMethod().hasActiveBody()) ){
                        SootMethod sm = ((AbstractInvokeExpr) useBox.getValue()).getMethod();
                        checkMethodStatus(unit,outSet, sm, "removeUpdates", "requestLocationUpdates" );
                        /*UnitGraph ug = new ClassicCompleteUnitGraph(sm.getActiveBody());
                        ResourceLeakAnalysis ra = new ResourceLeakAnalysis(ug, sm);
                        Unit lastUnit = sm.getActiveBody().getUnits().getLast();
                        for(Result rs: ra.getFlowAfter(lastUnit)) {
                            if(rs.getFinalMethod().getName().contains("removeUpdates")){
                                if(checkAndRemove(outSet, rs.getArgs(), "requestLocationUpdates", "removeUpdates")){
                                    rs.getPathMethods().add(new Pair<>(((AbstractInvokeExpr) useBox.getValue()) , parentMethod));
                                    outSet.add(rs);
                                }
                            }
                        }*/
                    }
                }
                //
            }
        }

        //return;
    }

    public Result produceNewResult(Unit u, Value v){
        Result result =  new Result();
        List<Pair<Unit, SootMethod>> path = new ArrayList<>();
        Pair<Unit, SootMethod> pair =  new Pair<>((Unit) u, parentMethod);
        path.add(pair);
        result.setFinalMethod(((AbstractInvokeExpr) v).getMethod());
        result.setPathMethods(path);
        result.setArgs(((AbstractInvokeExpr) v).getArgs());
        return result;



    }
//requestLocationUpdates - removeUpdates


    protected void generate(LeakFlowSet inSet, Unit unit, LeakFlowSet outSet){
        for (ValueBox useBox : unit.getUseBoxes()) {
            if(useBox.getValue() instanceof AbstractInvokeExpr) {
                if(((AbstractInvokeExpr) useBox.getValue()).getMethod().getName().contains("requestLocationUpdates")){
                    //System.out.println("shit");
                    //System.out.println("6666666");
                    if(checkAndRemove(outSet,((AbstractInvokeExpr) useBox.getValue()).getArgs(),"removeUpdates", "requestLocationUpdates")){
                        Result newResult = produceNewResult(unit,useBox.getValue());
                        outSet.add(newResult);
                    }
                }
                else{
                    if( (((AbstractInvokeExpr) useBox.getValue()).getMethod().hasActiveBody()) ){
                        SootMethod sm = ((AbstractInvokeExpr) useBox.getValue()).getMethod();
                        checkMethodStatus(unit,outSet, sm, "requestLocationUpdates", "removeUpdates" );
                        /*UnitGraph ug = new ClassicCompleteUnitGraph(sm.getActiveBody());
                        ResourceLeakAnalysis ra = new ResourceLeakAnalysis(ug, sm);
                        Unit lastUnit = sm.getActiveBody().getUnits().getLast();
                        for(Result rs: ra.getFlowAfter(lastUnit)) {
                            if(rs.getFinalMethod().getName().contains("requestLocationUpdates")){
                                if(checkAndRemove(outSet, rs.getArgs(),"removeUpdates", "requestLocationUpdates")){
                                    rs.getPathMethods().add(new Pair<>(((AbstractInvokeExpr) useBox.getValue()) , parentMethod));
                                    outSet.add(rs);
                                }
                            }
                        }*/
                    }
                }
            }
        }
        //return;
    }

}

