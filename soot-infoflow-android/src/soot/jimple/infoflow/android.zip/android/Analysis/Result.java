package soot.jimple.infoflow.android.Analysis;

import javafx.util.Pair;
import soot.SootClass;
import soot.SootMethod;
import soot.Unit;
import soot.Value;
import soot.jimple.internal.AbstractInvokeExpr;

import java.util.List;

public class Result {
    private SootClass callBackClass;
    private SootMethod callBackMethod;
    private List<Pair<Unit, SootMethod>> pathMethods;
    private SootMethod finalMethod;
    private List<Value> args;

    public SootClass getCallBackClass() {
        return callBackClass;
    }

    public void setCallBackClass(SootClass callBackClass) {
        this.callBackClass = callBackClass;
    }

    public SootMethod getCallBackMethod() {
        return callBackMethod;
    }

    public void setCallBackMethod(SootMethod callBackMethod) {
        this.callBackMethod = callBackMethod;
    }

    public List<Pair<Unit, SootMethod>> getPathMethods() {
        return pathMethods;
    }

    public void setPathMethods(List<Pair<Unit, SootMethod>> pathMethods) {
        this.pathMethods = pathMethods;
    }

    public SootMethod getFinalMethod() {
        return finalMethod;
    }

    public void setFinalMethod(SootMethod finalMethod) {
        this.finalMethod = finalMethod;
    }

    public List<Value> getArgs() {
        return args;
    }

    public void setArgs(List<Value> args) {
        this.args = args;
    }
}
