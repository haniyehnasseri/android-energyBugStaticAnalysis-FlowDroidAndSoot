package soot.jimple.infoflow.android.Analysis;

import soot.Local;
import soot.toolkits.scalar.AbstractBoundedFlowSet;
import soot.toolkits.scalar.AbstractFlowSet;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class LeakFlowSet extends AbstractBoundedFlowSet<Result> {

    private Set<Result> resources = new HashSet<>();
    public LeakFlowSet() {
        super();
    }
    @Override
    public LeakFlowSet clone() {
        LeakFlowSet myClone = new LeakFlowSet();
        myClone.resources.addAll(this.resources);
        return myClone;
    }

    @Override
    public boolean isEmpty() {
        return resources.isEmpty();
    }

    @Override
    public int size() {
        return resources.size();
    }

    @Override
    public void add(Result result) {
        resources.add(result);
    }

    @Override
    public void remove(Result result) {
        if(resources.contains(result))
            resources.remove(result);
    }

    @Override
    public boolean contains(Result result) {
        return resources.contains(result);
    }

    @Override
    public Iterator<Result> iterator() {
        return resources.iterator();
    }

    @Override
    public List<Result> toList() {
        return resources.stream().collect(Collectors.toList());
    }
}
