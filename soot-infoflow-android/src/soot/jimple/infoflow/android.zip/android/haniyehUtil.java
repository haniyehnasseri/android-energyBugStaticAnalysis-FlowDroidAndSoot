package soot.jimple.infoflow.android;

import com.google.common.collect.Iterators;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import javafx.util.Pair;
import org.xmlpull.v1.XmlPullParserException;
import soot.*;
import soot.jimple.AssignStmt;
import soot.jimple.InvokeStmt;
import soot.jimple.JimpleBody;
import soot.jimple.infoflow.android.Analysis.ResourceLeakAnalysis;
import soot.jimple.infoflow.android.Analysis.Result;
import soot.jimple.infoflow.android.axml.AXmlAttribute;
import soot.jimple.infoflow.android.axml.AXmlHandler;
import soot.jimple.infoflow.android.axml.AXmlNode;
import soot.jimple.infoflow.android.callbacks.AndroidCallbackDefinition;
import soot.jimple.infoflow.android.manifest.ProcessManifest;
import soot.jimple.internal.*;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;
import soot.toolkits.graph.ClassicCompleteUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.util.HashMultiMap;
import soot.util.MultiMap;

import java.io.IOException;
import java.util.*;

public class haniyehUtil {




    private static haniyehUtil instance;
    private SetupApplication analyzer;
    private List<String> paths = new ArrayList<>();
    public MultiMap<SootClass, SootMethod> callbackMethods = new HashMultiMap<>();
    public Map<SootMethod, Map<String, String>> localDefs = new HashMap<>();
    public CallGraph cg;
    public List<SootMethod> Queue = new ArrayList<>();
    public Map<String, ResourceLeakAnalysis> notVisitedMethodToAnalysis =  new HashMap<>();
    public List<String> beingVisitedMethods = new ArrayList<>();
    //public Map<String, Result> visitedMethodResult =  new HashMap<>();
    public Map<String, List<Result>> results = new HashMap<>();


    public haniyehUtil(){
        cg = Scene.v().getCallGraph();

    }

    public static haniyehUtil getInstance() {
        if(instance == null){
            instance = new haniyehUtil();
        }
        return instance;
    }
    public SetupApplication getAnalyzer() {
        return analyzer;
    }

    public void setAnalyzer(SetupApplication analyzer) {
        this.analyzer = analyzer;
    }

    public void analyzeActivity(SootClass activity) throws IOException, XmlPullParserException {
        //System.out.println(activity.getName());
        analyzer.calculateCallbacks(null,activity);
        //System.out.println(analyzer.getCallbackClasses());


        for(Iterator<AndroidCallbackDefinition> ad = analyzer.callbackMethods.get(activity).iterator(); ad.hasNext();){
            AndroidCallbackDefinition androidCallbackDefinition = ad.next();
            if(!androidCallbackDefinition.getTargetMethod().getDeclaringClass().getName().startsWith("androidx")){
                callbackMethods.put(activity,androidCallbackDefinition.getTargetMethod());
            }
            //if(checkHasMethod(androidCallbackDefinition.getTargetMethod().getName(), activity) != null){
                //System.out.println(h.checkHasMethod(androidCallbackDefinition.getTargetMethod().getName(), mainActivityClass).getSignature());

            //}
        }

        System.out.println(activity.getName());

        for(SootMethod sm: callbackMethods.get(activity)){
            System.out.println(sm);
        }
        //System.out.println(callbackMethods.keySet());
        //System.out.println(analyzer.entrypoints);

        /*SootMethod sm1 = Scene.v().getMethod("<com.example.myapplication.LocationTrack: android.location.Location getLocation()>");
        SootMethod sm2 = Scene.v().getMethod("<com.example.myapplication.LocationTrack: void stopListener()>");
        UnitGraph ug = new ClassicCompleteUnitGraph( sm1.retrieveActiveBody());
        UnitGraph ug2 = new ClassicCompleteUnitGraph( sm2.retrieveActiveBody());

        for(Iterator<Unit> it = ug.iterator(); it.hasNext();) {
            Unit unit = it.next();
            for (ValueBox useBox : unit.getUseBoxes()) {
                if(useBox.getValue() instanceof AbstractInvokeExpr &&
                        ((AbstractInvokeExpr) useBox.getValue()).getMethod().getName().contains("requestLocationUpdates")){
                    System.out.println("num 1");
                    List<Value> args,args2;
                    args = ((AbstractInvokeExpr) useBox.getValue()).getArgs();
                    for(Iterator<Unit> it2 = ug2.iterator(); it2.hasNext();) {
                        Unit unit2 = it2.next();


                        for (ValueBox useBox2 : unit2.getUseBoxes()) {
                            if(useBox2.getValue() instanceof AbstractInvokeExpr &&
                                    ((AbstractInvokeExpr) useBox2.getValue()).getMethod().getName().contains("removeUpdates")){
                                args2 = ((AbstractInvokeExpr) useBox2.getValue()).getArgs();

                                System.out.println(args);
                                System.out.println(args2);
                                for(Value ar1: args){
                                    for(Value ar2: args2){

                                        System.out.println(ar2.toString());
                                        System.out.println((JimpleLocal) ar2.);
                                        if(ar1.equivHashCode() == ar2.equivHashCode()){
                                            System.out.println("hehhhhhhhhhhhhhhhhhhhhhhhhhhhh");
                                        }
                                        else{
                                            System.out.println("nooooooooooooooooooooo");
                                        }
                                    }
                                }
                            }
                        }

                    }
                }
            }

        }*/




        //SootMethod sm1 = Scene.v().getMethod("<android.app.Activity: void startActivity(android.content.Intent)>");
        //System.out.println(sm1);
        //analyzeCallBackMethod(sm1);

        for(SootMethod sm: callbackMethods.get(activity)){

            /*if(sm.getName().contains("getLocation")){
                System.out.println("Yessssssssssssssssssssssssssssssssss");
                analyzeCallBackMethod(sm);
            }*/

            Queue.clear();
            analyzeCallBackMethod(sm);


        }
        /*for(String methodSig: notVisitedMethodToAnalysis.keySet()){
                System.out.println(methodSig);
                System.out.println(":");
                System.out.println(notVisitedMethodToAnalysis.get(methodSig));
        }*/
        //System.out.println(callbackMethods.get(activity));
    }

    public void analyzeCallBackMethod (SootMethod sm){
        //if (sm.hasActiveBody() && !notVisitedMethodToAnalysis.containsKey(sm.getSignature())){
            //UnitGraph unitGraph = new ClassicCompleteUnitGraph( sm.retrieveActiveBody());
            //ResourceLeakAnalysis resourceLeakAnalysis = new ResourceLeakAnalysis(unitGraph, sm);
            //notVisitedMethodToAnalysis.put(sm.getSignature(), resourceLeakAnalysis);
            Queue.add(sm);
            while(!Queue.isEmpty()){
                SootMethod sootMethod = Queue.remove(0);
                UnitGraph unitGraph = new ClassicCompleteUnitGraph( sootMethod.retrieveActiveBody());
                ResourceLeakAnalysis resourceLeakAnalysis = new ResourceLeakAnalysis(unitGraph, sootMethod);
                notVisitedMethodToAnalysis.put(sootMethod.getSignature(), resourceLeakAnalysis);
                for(Iterator<Edge> children =  cg.edgesOutOf(sootMethod); children.hasNext();){
                    Edge child = children.next();
                    //SootMethod target = child.tgt();
                    if((child.tgt() != null) && (child.tgt().hasActiveBody()) && (!notVisitedMethodToAnalysis.containsKey(child.tgt().getSignature()))
                    && (!Queue.contains(child.tgt())) && (!child.tgt().getDeclaringClass().getName().startsWith("androidx"))){
                        Queue.add(child.tgt());
                    }
                }
            }

            UnitGraph sootCallBackMethodGraph = new ClassicCompleteUnitGraph( sm.retrieveActiveBody());
            analyzeUnitGraph2(sootCallBackMethodGraph,sm);


            //System.out.println("11111111");

            //analyzeUnitGraph2(ug,sm);
        //}



    }

    public void analyzeUnitGraph2(UnitGraph unitGraph, SootMethod sm){

        if(notVisitedMethodToAnalysis.containsKey(sm.getSignature())) {
            ResourceLeakAnalysis ra = notVisitedMethodToAnalysis.get(sm.getSignature());
            notVisitedMethodToAnalysis.remove(sm.getSignature());
            beingVisitedMethods.add(sm.getSignature());
            ra.start();

            Unit lastUnit = sm.getActiveBody().getUnits().getLast();
            List<Result> methodResults = new ArrayList<>();

            for(Result rs: ra.getFlowAfter(lastUnit)){
                rs.setCallBackClass(sm.getDeclaringClass());
                rs.setCallBackMethod(sm);
                methodResults.add(rs);
            }
            results.put(sm.getSignature(), methodResults);

        }

        //System.out.println(results.get(sm.getSignature()));
        for(Result rs: results.get(sm.getSignature())){
            for(Pair<Unit, SootMethod> p : rs.getPathMethods()){
                System.out.println(p.getKey());
                System.out.println(p.getValue());
            }
        }
        System.out.println("-----------------------------");

        //if(!ra.getFlowAfter(lastUnit).isEmpty()){
            //System.out.println("    Line " + unit.getJavaSourceStartLineNumber() +": " + npa.analysisMode + " NullPointer usage of local " + usedLocal + " in unit " + unit);
       // }
    }

    public  void analyzeUnitGraph(UnitGraph unitGraph, SootMethod sm){
        /*if(sm.getName().contains("onClick")){
            for(Iterator<Unit> it = unitGraph.iterator(); it.hasNext();) {
                System.out.println(it.next());
            }

        }*/
        //int index = 0;

        for(Iterator<Unit> it = unitGraph.iterator(); it.hasNext();) {
            System.out.println("3333333");
            //index += 1;
            Unit unit = it.next();
            System.out.println(unit);
            /*for(UnitBox u :unit.getBoxesPointingToThis()){
                System.out.println("uuu");
                System.out.println(u);

                System.out.println("uuu");
            }
            for (ValueBox defBox: unit.getDefBoxes()){
                System.out.println("tttt");
                System.out.println(defBox);
                System.out.println(defBox.getValue());
                System.out.println("tttt");
            }*/
            for (ValueBox useBox : unit.getUseBoxes()) {

                //if (useBox.getValue() instanceof AbstractInvokeExpr) {
                    //outSet.add((AbstractBinopExpr) useBox.getValue());
                    System.out.println("------------------>");
                    System.out.println(sm.getSignature());
                    //System.out.println(unit.getUseBoxes());
                    System.out.println(useBox);
                    /*if(useBox instanceof IdentityRefBox){
                        System.out.println("Hellllooooooooooooooooooooo");
                        System.out.println(useBox.getValue().toString());
                    }*/
                    if(useBox.getValue() instanceof AbstractInvokeExpr){
                        SootMethod sm1 = ((AbstractInvokeExpr) useBox.getValue()).getMethod();
                        //List<ValueBox> a = useBox.getValue().getUseBoxes();

                        System.out.println(sm1);

                        //((AbstractInvokeExpr) useBox.getValue()).getArg(4);
                        List<Value> args = ((AbstractInvokeExpr) useBox.getValue()).getArgs();
                        System.out.println(args );
                        for(Value arg: args){
                            System.out.println("*******");
                            if(arg instanceof Local){
                                System.out.println(((Local) arg).getName());
                            }
                            System.out.println(arg.getUseBoxes());
                            System.out.println(arg.toString());
                            System.out.println(Scene.v().getSootClass(arg.getType().toString()).getName());
                            System.out.println(Scene.v().getSootClass(arg.getType().toString()).implementsInterface("android.location.LocationListener"));
                            System.out.println(Scene.v().getSootClass(arg.getType().toString()).getSuperclass());
                            System.out.println("********************");
                        }
                        //((AbstractInvokeExpr) useBox.getValue()).getArgBox(3);
                    }
                    //System.out.println(useBox.getValue() instanceof AbstractInvokeExpr);
                    //System.out.println(unit);
                    System.out.println("...................>");
                //}
            }
            /*if (unit instanceof JInvokeStmt){
                System.out.println("------------------>");
                System.out.println(sm.getSignature());
                System.out.println(unit.getUseBoxes());
                System.out.println(((JInvokeStmt) unit).getInvokeExpr().getMethod().getSignature());
                System.out.println(unit);
                System.out.println("...................>");

            }*/
            //System.out.println(unit);
        }
    }
    private  void showPathsCallGraph(CallGraph cg, SootMethod sm, String currentPath){
        //System.out.println("1");
        //List<SootMethod> entryPoints = Scene.v().getEntryPoints();
        if(currentPath.split("------->").length > 10){
            //System.out.println("Long Path Finished.");
            //System.out.println(currentPath);
            //paths.add(currentPath);
            return;
        }
        Iterator<Edge> children = cg.edgesOutOf(sm);
        int size = Iterators.size(children);
        if(size == 0){
            System.out.println("Path Finished.");
            System.out.println(currentPath);
            paths.add(currentPath);
            return;
        }
        //System.out.println(children.hasNext());
        for(Iterator<Edge> it = cg.edgesOutOf(sm); it.hasNext(); ){
            //System.out.println("hi");
            Edge child = it.next();
            //System.out.println(child.tgt());
            //System.out.println(currentPath);
            showPathsCallGraph(cg, child.tgt(), currentPath + "------->" + child.tgt().getSignature());

        }
        return;

    }
    private static void dumpCallGraph(CallGraph cg){
        Iterator<Edge> itr = cg.iterator();
        Map<String, Set<String>> map = new HashMap<String, Set<String>>();

        while(itr.hasNext()){
            Edge e = itr.next();
            String srcSig = "";
            String destSig = "";
            if (e.getSrc() != null){
                srcSig = e.getSrc().toString();
            }
            if (e.getTgt() != null){
                destSig = e.getTgt().toString();
            }
            Set<String> neighborSet;
            if(map.containsKey(srcSig)){
                neighborSet = map.get(srcSig);
            }
            else{
                neighborSet = new HashSet<String>();
            }
            neighborSet.add(destSig);
            map.put(srcSig, neighborSet );

        }
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String json = gson.toJson(map);
        System.out.println(json);
        //return json;
    }
    public SootMethod checkHasMethod(String name, SootClass st){
        for(SootMethod sm: st.getMethods()){
            if(sm.getName().contains(name)){
                return sm;
            }
        }
        return null;




    }


    public String getMainActivityName(String apkFileLocation) {
        String mainActivityName = null;
        try {
            ProcessManifest pm = new ProcessManifest(apkFileLocation);
            AXmlHandler axmlh = pm.getAXml();
            // Find main activity and remove main intent-filter
            List<AXmlNode> anodes = axmlh.getNodesWithTag("activity");
            for (AXmlNode an : anodes) {
                boolean hasMain = false;
                boolean hasLauncher = false;
                AXmlNode filter = null;
                AXmlAttribute aname = an.getAttribute("name");
                String aval = (String) aname.getValue();
                //System.out.println("activity: " + aval);
                for (AXmlNode ch : an.getChildren()) {
                    //System.out.println("children: " + ch);
                }
                List<AXmlNode> fnodes = an.getChildrenWithTag("intent-filter");
                for (AXmlNode fn : fnodes) {
                    hasMain = false;
                    hasLauncher = false;
                    // check action
                    List<AXmlNode> acnodes = fn.getChildrenWithTag("action");
                    for (AXmlNode acn : acnodes) {
                        AXmlAttribute acname = acn.getAttribute("name");
                        String acval = (String) acname.getValue();
                        //System.out.println("action: " + acval);
                        if (acval.equals("android.intent.action.MAIN")) {
                            hasMain = true;
                        }
                    }
                    // check category
                    List<AXmlNode> catnodes = fn.getChildrenWithTag("category");
                    for (AXmlNode catn : catnodes) {
                        AXmlAttribute catname = catn.getAttribute("name");
                        String catval = (String) catname.getValue();
                        //System.out.println("category: " + catval);
                        if (catval.equals("android.intent.category.LAUNCHER")) {
                            hasLauncher = true;
                            filter = fn;
                        }
                    }
                    if (hasLauncher && hasMain) {
                        break;
                    }
                }
                if (hasLauncher && hasMain) {
                    // replace name with the activity waiting for the connection to the PDP
                    //System.out.println("main activity is: " + aval);
                    //System.out.println("excluding filter: " + filter);
                    filter.exclude();
                    mainActivityName = aval;
                    break;
                }
            }
        }
         catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return mainActivityName;
    }
}