package soot.jimple.infoflow.android.manifest;

/**
 * Interface for services inside an Android app
 * 
 * @author Steven Arzt
 *
 */
public interface IService extends IAndroidComponent {

}
