package soot.jimple.infoflow.android.manifest;

/**
 * Interface for broadcast receivers inside an Android app
 * 
 * @author Steven Arzt
 *
 */
public interface IBroadcastReceiver extends IAndroidComponent {

}
