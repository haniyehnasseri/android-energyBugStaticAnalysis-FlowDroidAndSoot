package soot.jimple.infoflow.android.manifest;

/**
 * Interface for content providers inside an Android app
 * 
 * @author Steven Arzt
 *
 */
public interface IContentProvider extends IAndroidComponent {

}
