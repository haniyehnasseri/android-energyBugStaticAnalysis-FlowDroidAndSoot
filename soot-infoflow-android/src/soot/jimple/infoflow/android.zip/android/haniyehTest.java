package soot.jimple.infoflow.android;

import com.google.common.collect.Iterators;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.graphstream.ui.layout.Layout;
import org.graphstream.ui.swingViewer.Viewer;
import org.xmlpull.v1.XmlPullParserException;
import soot.*;
import soot.jimple.infoflow.android.callbacks.AndroidCallbackDefinition;
import soot.jimple.infoflow.results.InfoflowResults;
import soot.jimple.internal.*;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;
import soot.toolkits.graph.ClassicCompleteUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.graph.*;

import java.io.IOException;
import java.util.*;
import org.graphstream.graph.*;
import soot.util.HashMultiMap;
import soot.util.MultiMap;

public class haniyehTest {


    public static Graph graph;
    public static Viewer viewer;





    public static void main(String[] args) throws IOException, XmlPullParserException {

        List<String> componentCallBacks = new ArrayList<>();
        componentCallBacks.add("onCreate");
        componentCallBacks.add("onStart");
        componentCallBacks.add("onResume");
        componentCallBacks.add("onPause");
        componentCallBacks.add("onStop");
        componentCallBacks.add("onDestroy");
        componentCallBacks.add("onRestart");

        //C:\Users\haniye\AndroidStudioProjects\MyApplication\release\app-release.apk
        Map<String, Set<String>> map = new HashMap<String, Set<String>>();
        // Initialize Soot
        SetupApplication analyzer = new SetupApplication("C:\\Users\\haniye\\AppData\\Local\\Android\\Sdk\\platforms",
                "C:\\Users\\haniye\\AndroidStudioProjects\\MyApplication\\release\\app-release.apk");

        InfoflowResults results = analyzer.runInfoflow("C:\\Users\\haniye\\OneDrive\\Desktop\\flowdroid2\\FlowDroid\\soot-infoflow-android\\testAPKs\\SourceSinkDefinitions\\sourcesAndSinks.xml");
        CallGraph cg = Scene.v().getCallGraph();
        System.out.println("Call Graph construct finished ! ");
        UnitGraph ug;
        //System.out.println(analyzer.callbackMethods.size());

        //System.out.println(a.getResultSet());
        //analyzer.constructCallgraph();
        //System.out.println(analyzer.getSources());
        //System.out.println(Scene.v().getClasses());
        //dumpCallGraph(Scene.v().getCallGraph());




        haniyehUtil.getInstance().setAnalyzer(analyzer);
        String mainActivityName = haniyehUtil.getInstance().getMainActivityName("C:\\Users\\haniye\\AndroidStudioProjects\\MyApplication\\release\\app-release.apk");
        SootClass mainActivityClass = Scene.v().getSootClass(mainActivityName);



        haniyehUtil.getInstance().analyzeActivity(mainActivityClass);
        for(SootClass sc: analyzer.getEntrypointClasses()){
            if(!sc.equals(mainActivityClass)){
                //System.out.println("YEAYY");
                haniyehUtil.getInstance().analyzeActivity(sc);
            }

        }


        //System.out.println(callbackMethods);



        /*for(SootMethod sm: Scene.v().getEntryPoints()){
            //System.out.println(sm.getSignature());



            //System.out.println(sc.getMethod("void sendMessage(android.view.View)").getSource());
            //showPathsCallGraph(Scene.v().getCallGraph(), sm, sm.getSignature());
            //ug = new ClassicCompleteUnitGraph(sm.getActiveBody());
            //analyzeUnitGraph(ug);
        }*/


        //System.out.println(paths.get(0));


        // Iterate over the callgraph
        //CallGraph cg = Scene.v().getCallGraph();
        //for (Iterator<Edge> edgeIt = cg.iterator(); edgeIt.hasNext(); ) {

          //  Edge edge = edgeIt.next();

            //dummyMainMethod_com_example_myapplication_MainActivity"
            /*if (edge.src() != null && edge.src().getSignature().equals("<android.app.Activity: void startActivity(android.content.Intent)>")
            ){
                System.out.println("1111");
                Unit uSrc = edge.srcStmt();
                System.out.println(uSrc);
                //Iterator<Edge> e = cg.edgesOutOf(uSrc);
                for (Iterator<Edge> e = cg.edgesOutOf(uSrc); e.hasNext(); )
                {
                    Edge ee = e.next();
                    System.out.println(ee);

                }*/

                //SootMethod smSrc = edge.src();
                /*for (Iterator<Edge> t = cg.edgesOutOf(edge.getSrc()); t.hasNext();){
                    Edge ed = edgeIt.next();
                    System.out.println(ed.tgt());
                }*/

        //System.out.println(edge.tgt());

        //}
            /*SootMethod smSrc = edge.src();
            Unit uSrc = edge.srcStmt();
            SootMethod smDest = edge.tgt();


            System.out.println("Edge from " + uSrc + " in " + smSrc + " to " + smDest );*/
            /*if (smSrc.getDeclaringClass().hasSuperclass()){
                System.out.println("src class" + smSrc.getDeclaringClass().getType());
            }*/
        /*}
    }
}}

         */
    }}
